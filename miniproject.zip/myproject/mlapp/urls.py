# mlapp/urls.py
from django.urls import path
from . import views  # views 모듈을 불러옵니다.

urlpatterns = [
    path('train/', views.train_model_view, name='train_model'),
    path('predict/', views.predict_result_view, name='predict_result'),
    path('retrain_random_forest/', views.retrain_random_forest_view, name='retrain_random_forest'),  # URL 패턴 확인
]
